<?php
namespace storedd\models;
use storedd\modules\db;
class Model_Base extends RedBean_SimpleModel{

}
?>