<?php
namespace storedd\models;
class attributeDefinition extends base{
    
}
?>