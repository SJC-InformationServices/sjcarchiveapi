<?php
namespace storedd\models;
class entities extends base
{
    private $id=null;
    private $id_text=null;
        
}
?>